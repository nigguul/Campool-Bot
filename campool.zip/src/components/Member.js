class Member {
    constructor(dsMember) {
        this.team = null;
    }
}